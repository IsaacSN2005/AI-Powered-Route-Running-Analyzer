import React, { useState } from 'react';
import { 
  Upload, 
  ChevronLeft, 
  Share2, 
  Play, 
  RotateCcw, 
  RotateCw, 
  Volume2, 
  Maximize, 
  User, 
  Settings, 
  Info,
  Activity,
  Download
} from 'lucide-react';
import { motion } from 'motion/react';

// Types
interface Metric {
  label: string;
  value: string | number;
  unit?: string;
  status?: 'Elite' | 'Optimal' | 'Average' | 'Poor';
  description: string;
}

interface Analysis {
  id: string;
  title: string;
  time: string;
  score: number;
  image: string;
  metrics: Metric[];
}

const DEFAULT_METRICS_TEMPLATE: Metric[] = [
  {
    label: 'Route Sharpness',
    value: 92,
    unit: '/ 100',
    status: 'Elite',
    description: 'Precision of the break angle and consistency of footwork.'
  },
  {
    label: 'Deceleration Rate',
    value: -4.2,
    unit: 'm/s²',
    status: 'Optimal',
    description: 'Rate of velocity reduction prior to route break.'
  },
  {
    label: 'Re-acceleration',
    value: 0.8,
    unit: 'seconds',
    status: 'Average',
    description: 'Time to return to 90% max velocity post-break.'
  },
  {
    label: 'Break Angle',
    value: '88°',
    unit: 'Deg.',
    description: 'Measured angle of direction change at the break point.'
  },
  {
    label: 'Hip Sink Proxy',
    value: 4.5,
    unit: 'cm drop',
    status: 'Elite',
    description: 'Vertical center-of-mass displacement during break.'
  },
  {
    label: 'Max Speed',
    value: 19.4,
    unit: 'mph',
    description: 'Peak velocity reached during the vertical stem.'
  },
  {
    label: 'Acceleration',
    value: 8.2,
    unit: 'm/s²',
    status: 'Elite',
    description: 'Initial burst and rate of velocity increase off the line of scrimmage.'
  }
];

const RECENT_ANALYSES: Analysis[] = [
  {
    id: '1',
    title: 'Dig Route - Smith',
    time: '2m ago',
    score: 92,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDFv8YZnjBnVg5UeH7u_GJOPN6JGMLhTcfZwGavthazSI0JK7Cetkt_3_797ohbbx5fLvq7ZLU17n0c4cNY6WsU-9PoThlvHLzUJsnnCgRxR8yQ6ELpVDVpm_9CWAB46UTRhaktcPRCVhUFrFZieB6nJGVeIc4JlugxfYv6mIoABzHRGsT29cVfhMAdZ7WNOKa-HQ9CooXZUDUO5zwsbutm3j-wBFChJspO5JY6PEvhBTCy0bOOXNAkjhFdUuzglXv8FHSNawI46Xs',
    metrics: [...DEFAULT_METRICS_TEMPLATE]
  },
  {
    id: '2',
    title: 'Post - Jones',
    time: '1h ago',
    score: 88,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBu2ZG5ZLfogPBRbpmeDHycnCaM1pkZvwOCI834xkuNUDzAluiuzHxl6Qb6j6O3OQwmapR5Wx--fs8dx74agzZ5UGf3jos0bxf7tGCqCFBt49oTXgsZG7XXdyAsJ8WNZCKHszsjH2aTpitoSPRE7yVlWsUNiimKJc2RDhE8-BqbTX06dFtJp7lMgZqdLfLDDbE0qOFp6Kc-RDrOJTOg_IxtCTr2StPg-_6GEmgPRAnPb6EMMlzCpKjlPt58ruSHckMtAvczeTDmUiI',
    metrics: DEFAULT_METRICS_TEMPLATE.map(m => ({ ...m, value: typeof m.value === 'number' ? Math.round(m.value * 0.9 * 10) / 10 : m.value }))
  },
  {
    id: '3',
    title: 'Out Route - Williams',
    time: '3h ago',
    score: 95,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBeVytIovuj4iLP9g_hlH3M8JvINOBMXRiVdQCMjaWM_1jdouy7zHGNTQ24Y2L69G_cuzYec91AXP6DfjpkytUoTMu5fMGVlIyWJaGwx1qTgoFDjIn1IwiqDq9pfl1aK67n3kLHezkOEIYG9jVTAzGIfmqOaU9YV5PQNf2MiR0MB8u3TbBAWnBbMvU5c-XfgY1av28qvwlNV8zhpJ_HoUVKCjawd927WEW12FQhxxnBGJRjkAdn2YXSQIzOiAJRaruA9fFpHSmAclc',
    metrics: DEFAULT_METRICS_TEMPLATE.map(m => ({ ...m, value: typeof m.value === 'number' ? Math.round(m.value * 1.1 * 10) / 10 : m.value }))
  }
];

export default function App() {
  const [analyses, setAnalyses] = useState<Analysis[]>(RECENT_ANALYSES);
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<string>('1');
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const selectedAnalysis = analyses.find(a => a.id === selectedAnalysisId) || analyses[0];

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const newId = Date.now().toString();
      
      // Generate randomized metrics to simulate backend processing
      const processedMetrics = DEFAULT_METRICS_TEMPLATE.map(m => {
        if (typeof m.value === 'number') {
          const variation = 0.8 + Math.random() * 0.4; // 80% to 120% of original
          return { ...m, value: Math.round(m.value * variation * 10) / 10 };
        }
        return m;
      });

      const newAnalysis: Analysis = {
        id: newId,
        title: file.name.split('.')[0] || 'New Analysis',
        time: 'Just now',
        score: Math.floor(Math.random() * (98 - 85 + 1)) + 85,
        image: `https://picsum.photos/seed/${newId}/200/200`,
        metrics: processedMetrics
      };
      setAnalyses([newAnalysis, ...analyses]);
      setSelectedAnalysisId(newId);
      
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(selectedAnalysis, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `route-analysis-${selectedAnalysis.title.toLowerCase().replace(/\s+/g, '-')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background-light dark:bg-background-dark">
      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="video/mp4,video/webm,video/quicktime"
        className="hidden" 
      />
      
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 bg-slate-50 dark:bg-slate-900/50 border-r border-slate-200 dark:border-slate-800 flex flex-col">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-primary rounded-lg p-1.5 flex items-center justify-center">
              <Activity className="text-white w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">RouteIQ</h1>
          </div>

          <button 
            onClick={handleUploadClick}
            className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold py-2.5 px-4 rounded-lg transition-colors mb-8 shadow-lg shadow-primary/20"
          >
            <Upload className="w-5 h-5" />
            <span>Upload Video</span>
          </button>

          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-2">Recent Analyses</h3>
            <div className="space-y-1 overflow-y-auto no-scrollbar max-h-[calc(100vh-320px)]">
              {analyses.map((analysis) => (
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={analysis.id}
                  onClick={() => setSelectedAnalysisId(analysis.id)}
                  className={`group flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all ${
                    analysis.id === selectedAnalysisId 
                      ? 'bg-slate-200 dark:bg-slate-800 border border-primary/20 shadow-sm' 
                      : 'hover:bg-slate-200 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="w-12 h-12 rounded-md bg-slate-300 dark:bg-slate-700 overflow-hidden flex-shrink-0">
                    <img 
                      className="w-full h-full object-cover" 
                      src={analysis.image} 
                      alt={analysis.title}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{analysis.title}</p>
                    <p className="text-xs text-slate-500">{analysis.time} • {analysis.score}% Score</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-8 border-b border-slate-200 dark:border-slate-800 shrink-0 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md">
          <div className="flex items-center gap-4">
            <ChevronLeft className="text-slate-400 w-6 h-6 cursor-pointer hover:text-slate-600" />
            <h2 className="text-lg font-bold">Analysis: {selectedAnalysis.title}</h2>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={handleExport}
              className="flex items-center gap-2 bg-slate-900 dark:bg-slate-100 text-slate-100 dark:text-slate-900 px-4 py-2 rounded-lg text-sm font-bold hover:opacity-90 transition-opacity"
            >
              <Download className="w-4 h-4" />
              Export Report
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
          {/* Video Player Section */}
          <section className="relative aspect-video w-full max-h-[500px] bg-black rounded-xl overflow-hidden shadow-2xl border border-slate-800">
            <img 
              className="w-full h-full object-cover opacity-60" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDV6fN6kXyWzcmfShRvE9AveOpNPfWuGX9DxYCGy9un7AkQe1yKdSqZookn7JIvcz_qL3CJsMTgDw5rZ9fSU5gpyqeSU5iEBtsoXLvGYwq-3od2jap39eI26MDxxPDuO78QE2eh68gBG0LIAwNPvK300zv6yA20LEfnVVmNA1MQkNEP5zEMQoBGh87uCJI5pa8VAyvQ-H9qZaCDo2uMDnz1od3nEAKt3pUFB2TomiNEmFxpS_Yrz24rz_Qk_y5YxcKXUEG2F5FGenM" 
              alt="Sideline view of an American football game"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-20 h-20 bg-primary/90 text-white rounded-full flex items-center justify-center shadow-xl backdrop-blur-sm"
              >
                <Play className="w-10 h-10 fill-current ml-1" />
              </motion.button>
            </div>

            {/* Overlay Metrics */}
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-2 rounded-lg border border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                <span className="text-[10px] font-mono text-white tracking-widest font-bold">LIVE TRACKING</span>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
              <div className="flex items-center gap-4 mb-3">
                <span className="text-xs text-white font-mono">00:32 / 02:45</span>
                <div className="flex-1 h-1 bg-white/20 rounded-full relative cursor-pointer group">
                  <div className="absolute top-0 left-0 w-1/3 h-full bg-primary rounded-full"></div>
                  <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-3 h-3 bg-white border-2 border-primary rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              </div>
              <div className="flex justify-between items-center text-white">
                <div className="flex items-center gap-6">
                  <RotateCcw className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
                  <Play className="w-6 h-6 cursor-pointer hover:text-primary fill-current" />
                  <RotateCw className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
                </div>
                <div className="flex items-center gap-4">
                  <Volume2 className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
                  <Maximize className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
                </div>
              </div>
            </div>
          </section>

          {/* 2D Route Visualization */}
          <section className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm overflow-hidden">
            <div className="flex justify-between items-center mb-6">
              <div className="space-y-1">
                <h3 className="text-lg font-bold">2D Route Visualization</h3>
                <p className="text-xs text-slate-500 font-medium">Structural diagram of route stem and break points</p>
              </div>
              <div className="flex gap-4 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-primary"></div>Route Path</div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-orange-400"></div>Break Point</div>
              </div>
            </div>
            
            <div className="relative w-full h-80 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden">
              {/* Subtle Field Markings */}
              <div className="absolute inset-0 opacity-20 pointer-events-none">
                <div className="absolute inset-x-0 h-px bg-slate-400 top-1/4"></div>
                <div className="absolute inset-x-0 h-px bg-slate-400 top-2/4"></div>
                <div className="absolute inset-x-0 h-px bg-slate-400 top-3/4"></div>
                <div className="absolute inset-y-0 w-px bg-slate-400 left-10"></div>
              </div>
              
              {/* Route Diagram SVG */}
              <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 800 320">
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#137fec" />
                  </marker>
                </defs>

                {/* Vertical Stem */}
                <motion.line 
                  initial={{ y2: 280 }}
                  animate={{ y2: 140 }}
                  transition={{ duration: 1, ease: "linear" }}
                  x1="50" y1="280" x2="50" y2="140" 
                  stroke="#137fec" 
                  strokeWidth="3" 
                  strokeDasharray="8 4"
                  className="opacity-40"
                />

                {/* Main Route Path */}
                <motion.path 
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                  d="M50,280 L50,140 L340,140" 
                  fill="none" 
                  stroke="#137fec" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth="4" 
                />

                {/* Break Point Emphasis */}
                <motion.circle 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.8, type: "spring" }}
                  cx="50" cy="140" fill="#fb923c" r="8" 
                  className="shadow-lg"
                />
                
                {/* Labels */}
                <g className="font-bold text-[10px] uppercase tracking-widest">
                  <text x="65" y="275" fill="#64748b">Release</text>
                  <text x="65" y="135" fill="#fb923c">The Break (88°)</text>
                  <text x="300" y="135" fill="#137fec">Finish</text>
                </g>
              </svg>

              {/* Contextual Labels */}
              <div className="absolute bottom-4 left-4 text-[9px] font-black text-slate-400 dark:text-slate-700 uppercase tracking-[0.2em]">Sideline Boundary</div>
              <div className="absolute top-4 left-4 text-[9px] font-black text-slate-400 dark:text-slate-700 uppercase tracking-[0.2em]">Line of Scrimmage</div>
            </div>
          </section>
        </div>
      </main>

      {/* Right Analytics Panel */}
      <aside className="w-80 flex-shrink-0 bg-slate-50 dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 overflow-y-auto no-scrollbar">
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 dark:text-white uppercase text-xs tracking-widest">Performance Metrics</h3>
            <Info className="text-slate-400 w-5 h-5 cursor-pointer hover:text-slate-600" />
          </div>

          <div className="grid grid-cols-1 gap-4">
            {selectedAnalysis.metrics.map((metric, idx) => (
              <motion.div 
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{metric.label}</span>
                  {metric.status && (
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter ${
                      metric.status === 'Elite' ? 'text-green-500 bg-green-500/10' :
                      metric.status === 'Optimal' ? 'text-blue-500 bg-blue-500/10' :
                      'text-yellow-500 bg-yellow-500/10'
                    }`}>
                      {metric.status}
                    </span>
                  )}
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-slate-900 dark:text-white">{metric.value}</span>
                  <span className="text-slate-400 text-xs font-medium">{metric.unit}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 leading-relaxed font-medium">
                  {metric.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
