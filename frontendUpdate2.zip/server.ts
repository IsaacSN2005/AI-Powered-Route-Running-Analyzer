import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Analysis
  // This is where your teammate's backend processing code will be integrated
  app.post("/api/analyze", async (req, res) => {
    console.log("Received analysis request...");
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Mock response data (Your teammate will replace this with real computer vision results)
    const mockResult = {
      score: Math.floor(Math.random() * (98 - 85 + 1)) + 85,
      image: `https://picsum.photos/seed/${Date.now()}/200/200`,
      metrics: [
        {
          label: 'Route Sharpness',
          value: 92,
          unit: '/ 100',
          status: 'Elite',
          description: 'Precision of the break angle and consistency of footwork.'
        },
        {
          label: 'Deceleration Rate',
          value: -4.2,
          unit: 'm/s²',
          status: 'Optimal',
          description: 'Rate of velocity reduction prior to route break.'
        },
        {
          label: 'Re-acceleration',
          value: 0.8,
          unit: 'seconds',
          status: 'Average',
          description: 'Time to return to 90% max velocity post-break.'
        },
        {
          label: 'Break Angle',
          value: '88°',
          unit: 'Deg.',
          description: 'Measured angle of direction change at the break point.'
        },
        {
          label: 'Hip Sink Proxy',
          value: 4.5,
          unit: 'cm drop',
          status: 'Elite',
          description: 'Vertical center-of-mass displacement during break.'
        },
        {
          label: 'Max Speed',
          value: 19.4,
          unit: 'mph',
          description: 'Peak velocity reached during the vertical stem.'
        },
        {
          label: 'Acceleration',
          value: 8.2,
          unit: 'm/s²',
          status: 'Elite',
          description: 'Initial burst and rate of velocity increase off the line of scrimmage.'
        }
      ]
    };

    res.json(mockResult);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
