export interface User {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
}

export interface Metric {
  label: string;
  value: string | number;
  unit?: string;
  status?: 'Elite' | 'Optimal' | 'Average' | 'Poor';
  description: string;
}

export interface Player {
  id: string;
  name: string;
  position: string;
  jerseyNumber: string;
  photoURL?: string;
}

export interface Analysis {
  id: string;
  uid: string;
  playerId: string;
  playerSnapshot: Player; // Store a snapshot of player info at time of analysis
  title: string;
  time: string;
  score: number;
  image: string;
  videoUrl?: string;
  metrics: Metric[];
  createdAt: Date;
}
